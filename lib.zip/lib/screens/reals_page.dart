import 'package:flutter/material.dart';

class RealsPage extends StatefulWidget {
  const RealsPage({super.key});

  @override
  State<RealsPage> createState() => _RealsPageState();
}

class _RealsPageState extends State<RealsPage> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
